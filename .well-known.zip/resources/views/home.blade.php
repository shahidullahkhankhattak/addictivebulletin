<!DOCTYPE html >
<html lang="en" @php if($lang == 'ur') { @endphp dir="rtl" @php } @endphp>
    @include('inc.head')
<body class="pushable @if($story) no-scroll @endif">
    <div id="app">
        @include('inc.sidebar.left')
        @include('inc.sidebar.right')
        @include('inc.topbar')
        @include('inc.home.content')
        @include('inc.sidebar.bottom')
    </div>
    @include('inc.scripts')
</body>
</html>
