<div class="ui bottom sidebar inverted menu visible">
    <router-link class="item" :to="'/'+lang+(source ? '/source/' + source : '')+'/category/world'">
        <i class="globe icon"></i>
        <?php echo e(__trans('World', $lang)); ?>

    </router-link>
    <router-link class="item" :to="'/'+lang+(source ? '/source/' + source : '')+'/category/national'">
        <i class="flag icon"></i>
        <?php echo e(__trans('National', $lang)); ?>

    </router-link>
    <router-link class="item" :to="'/'+lang+(source ? '/source/' + source : '')+'/category/sports'">
        <i class="baseball ball icon"></i>
        <?php echo e(__trans('Sports', $lang)); ?>

    </router-link>
    <router-link class="item" :to="'/'+lang+(source ? '/source/' + source : '')+'/category/technology'">
        <i class="desktop icon"></i>
        <?php echo e(__trans('Technology', $lang)); ?>

    </router-link>
    <router-link class="item" :to="'/'+lang+(source ? '/source/' + source : '')+'/category/business'">
        <i class="building icon"></i>
        <?php echo e(__trans('Business', $lang)); ?>

    </router-link>
    <router-link class="item" :to="'/'+lang+(source ? '/source/' + source : '')+'/category/health'">
        <i class="stethoscope icon"></i>
        <?php echo e(__trans('Health', $lang)); ?>

    </router-link>
    <router-link class="item" :to="'/'+lang+(source ? '/source/' + source : '')+'/category/others'">
        <i class="asterisk icon"></i>
        <?php echo e(__trans('Others', $lang)); ?>

    </router-link>
</div>

<?php /* /home/karma/Desktop/My Project/SNEWS/resources/views/inc/sidebar/bottom.blade.php */ ?>