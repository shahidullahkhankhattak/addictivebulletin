<div class="logoSidebar">
    <span class="l2"><?php echo e(__trans('Special', $lang)); ?></span>
    <span class="l3"><?php echo e(__trans('News', $lang)); ?></span>
</div>
<div class="ui left vertical inverted menu left-menu">
    <router-link class="item" :to="'/'+lang">
        <i class="newspaper outline icon"></i>
        <?php echo e(__trans('Latest', $lang)); ?>

    </router-link>
    <router-link class="item" :to="'/'+lang+'/trending'">
        <i class="chart line icon"></i>
        <?php echo e(__trans('Trending', $lang)); ?>

    </router-link>
</div>

<?php /* /home/karma/Desktop/My Project/SNEWS/resources/views/inc/sidebar/left-main.blade.php */ ?>