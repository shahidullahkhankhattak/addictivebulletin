<script src="/js/app.js"></script>
<script async src="https://static.addtoany.com/menu/page.js"></script>

<?php /* /home/karma/Desktop/My Project/SNEWS/resources/views/inc/scripts.blade.php */ ?>