<div class="news-article <?php if(!$story): ?> closed <?php endif; ?>" >
    <div class="full height" v-if="story">
        <div class="toc">
            <div class="news-sidebar">
                <div class="source-title" v-html="story.source">
                    <?php echo e($story ? $story->source : ''); ?>

                </div>
                <?php if($story): ?>
                <a class="original-news" v-if="!story" target="_blank" href="<?php echo e($story->url); ?>">
                    <?php if($lang == "en"): ?> View News On <?php endif; ?> <?php echo e($story->source); ?> <?php if($lang == "ur"): ?> "پہ دکھایں" <?php endif; ?></a>
                <?php endif; ?>
                <a class="original-news" v-if="story" target="_blank" :href="story.url">{{lang == 'english' ? 'View News On' : ''}} {{story ? story.source : ''}} {{lang == 'urdu' ? 'پہ دکھایں' : ''}}</a>
            </div>
            <?php if($story): ?>
            <div class="ui left vertical inverted menu left-menu" v-if="!story.related">
                <?php $__currentLoopData = $story->related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <router-link class="item" to="/<?php echo e($lang == "en" ? 'english' : 'urdu'); ?>/news/<?php echo e($related->id); ?>/<?php echo e($related->slug); ?>">
                    <span class="source"><?php echo e($related->source); ?></span>
                    <header class="sidebar-heading"><?php echo e($related->title); ?></header>
                </router-link>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <div class="ui left vertical inverted menu left-menu">
                    <router-link class="item" v-for="related in story.related" :to="'/'+lang+'/news/'+related.id+'/'+(related.slug ? related.slug : '' )">
                        <span class="source">{{related.source}}</span>
                        <header class="sidebar-heading">{{related.title}}</header>
                    </router-link>
            </div>
        </div>
        <div class="article">
            <div class="top_bar_wrapper">
                <div class="top_bar">
                    <a class="icon btn_close" @click="closeNews()"><i class="close icon"></i></a>
                    <ul class="actions">
                        <div class="a2a_kit a2a_kit_size_32 a2a_default_style">
                            <a class="a2a_button_facebook"></a>
                            <a class="a2a_button_twitter"></a>
                            <a class="a2a_button_pinterest"></a>
                            <a class="a2a_dd" href="https://www.addtoany.com/share"></a>
                        </div>
                    </ul>
                </div>
            </div>
            <div class="story_wrapper">

                <div class="story_media">
                    <img src="https://timesofindia.indiatimes.com/thumb/msid-68614246,width-400,resizemode-4/68614246.jpg?imglength=126871"
                        style="display: none;">
                </div>

                <h1 class="story_title" v-html="story.title"><?php echo e($story ? $story->title : ''); ?></h1>


                <div class="story_meta">
                    <span class="authors" v-html="story.author"><?php echo e($story ? $story->author : ''); ?></span>
                    <time class="pub_date" v-html="story.pub_date"><?php echo $story ? $story->pub_date : ''; ?></time>
                </div>

                <div class="story_content">
                    <div class="normal" v-html="story.body == '' ? story.description : story.body">
                        <?php echo e($story ? $story->body : ''); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /* /home/karma/Desktop/My Project/SNEWS/resources/views/inc/home/news.blade.php */ ?>