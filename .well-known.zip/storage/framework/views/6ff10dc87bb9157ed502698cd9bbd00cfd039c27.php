<div class="ui left vertical sidebar inverted menu main-sidebar overlay">
    <div class="logoSidebar">
        <span class="l2"><?php echo e(__trans('Special', $lang)); ?></span>
        <span class="l3"><?php echo e(__trans('News', $lang)); ?></span>
    </div>
    <router-link class="item" :to="'/'+lang">
        <i class="globe icon"></i>
        <?php echo e(__trans('Latest', $lang)); ?>

    </router-link>
    <router-link class="item" :to="'/'+lang+'/trending'">
        <i class="smile icon"></i>
        <?php echo e(__trans('Trending', $lang)); ?>

    </router-link>
</div>

<?php /* /home/univer16/snews.shahidullahkhan.com/resources/views/inc/sidebar/left.blade.php */ ?>