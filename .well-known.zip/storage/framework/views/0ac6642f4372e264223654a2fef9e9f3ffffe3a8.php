<script src="/js/app.js?v=15"></script>
<script async src="https://static.addtoany.com/menu/page.js"></script>
<?php /* /home/additwlr/public_html/resources/views/inc/scripts.blade.php */ ?>