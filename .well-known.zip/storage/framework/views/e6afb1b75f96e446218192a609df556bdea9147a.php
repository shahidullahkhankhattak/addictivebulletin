<div class="logoSidebar">
        <img src="/images/addictive_bulletin_logo_new.png" alt="addictive bulletin logo">
</div>

<a class="no-show" title="Latest" href="/<?php echo e($lang == 'en' ? 'english' : 'urdu'); ?>/"></a>
<a class="no-show" title="Trending" href="/<?php echo e($lang == 'en' ? 'english' : 'urdu'); ?>/trending"></a>
    
<div class="ui left vertical inverted menu left-menu">
    <router-link class="item" :to="'/'+lang">
        <i class="newspaper outline icon"></i>
        <?php echo e(__trans('Latest', $lang)); ?>

    </router-link>
    <router-link class="item" :to="'/'+lang+'/trending'">
        <i class="chart line icon"></i>
        <?php echo e(__trans('Trending', $lang)); ?>

    </router-link>
</div>

<?php /* /home/additwlr/public_html/resources/views/inc/sidebar/left-main.blade.php */ ?>