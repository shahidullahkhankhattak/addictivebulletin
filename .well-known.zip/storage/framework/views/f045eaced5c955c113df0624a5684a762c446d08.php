<div class="pusher">
    <div class="full height">
        <div class="toc">
            <?php echo $__env->make('inc.sidebar.left-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="article desc" v-if="source" style="padding-top:100px;padding-top: 100px;box-shadow: 0px 0px 10px lightgrey;margin-bottom:-70px;display:none" v-show="source">
                <div class="loader" @click="$router.push('/'+lang)">
                    <h3 v-html="sources.filter(s => s.slug == source)[0].source"></h3>
                    <span v-if="lang == 'english'" v-html="'view all sources'"></span>
                    <span v-else v-html="'سب زرائے سے خبریں دکھا یں'"></span>
                </div>
        </div>
        <div class="article" v-if="directLoad">
            <div class="ui link auto cards">
                <?php if(sizeof($news) == 0): ?>
                <div class="no-news"><?php echo e(__trans('No news found within selected filter.', $lang)); ?></div>
                <?php endif; ?>
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="card">
                    <div class="image">
                        <router-link
                            to="/<?php echo e($lang == "en" ? 'english' : 'urdu'); ?>/news/<?php echo e($article->id); ?>/<?php echo e($article->slug); ?>">
                            <img onload="fadeIn(this)"
                                src="http://newshunt.io/lib/thumb.php?w=200&h=150&src=<?php echo e($article->media); ?>">
                        </router-link>
                    </div>
                    <div class="content">
                        <header class="header">
                            <router-link
                                to="/<?php echo e($lang == "en" ? 'english' : 'urdu'); ?>/news/<?php echo e($article->id); ?>/<?php echo e($article->slug); ?>">
                                <?php echo e($article->title); ?></router-link>
                        </header>
                        <div class="meta">
                            <a><time><?php echo e($article->pub_date); ?></time> - <?php echo e($article->source); ?></a>
                        </div>
                        <p class="description">
                            <?php echo $article->description; ?>

                        </p>
                    </div>
                    <div class="extra content">
                        <span @click="likeNews(<?php echo e($article->id); ?>)">
                            <i class="heart icon" :style="{color: stories.filter(s => s.id == <?php echo e($article->id); ?>)[0].liked ? 'red' : ''}"></i>
                            <span v-html="stories.filter(s => s.id == <?php echo e($article->id); ?>)[0].likes"></span>
                        </span>
                    </div>
                </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="article" v-if="stories && !directLoad">
            <div class="ui link auto cards">
                <div class="no-news" v-if="lang == 'english' && stories.length == 0">No news found within selected filter.</div>
                <div class="no-news" v-else-if="lang == 'urdu' && stories.length == 0">منتخب فلٹر میں کوی خبر نہی ملی.</div>
                <article class="card" v-for="story in stories">
                    <div class="image">
                        <router-link
                            :to="'/'+lang+'/news/'+story.id+'/'+story.slug">
                            <img onload="fadeIn(this)"
                                :src="'http://newshunt.io/lib/thumb.php?w=200&h=150&src=' + story.media">
                        </router-link>
                    </div>
                    <div class="content">
                        <header class="header">
                            <router-link
                                :to="'/'+lang+'/news/'+story.id+'/'+story.slug">
                                {{story.title}}</router-link>
                        </header>
                        <div class="meta">
                            <a><time>{{story.pub_date}}</time> - {{story.source}}</a>
                        </div>
                        <p class="description" v-html="story.description">
                        </p>
                    </div>
                    <div class="extra content">
                        <span @click="likeNews(story.id)">
                            <i class="heart icon" :style="{color: stories.filter(s => s.id == story.id)[0].liked ? 'red' : ''}"></i>
                            <span>{{story.likes}}</span>
                        </span>
                    </div>
                </article>
            </div>
        </div>
        <div class="article" v-if="loading" :style="{'padding-top': (stories.length > 0 ? '0px' : '90px')}">
                <div class="loader">
                        <img src="https://loading.io/spinners/coolors/lg.palette-rotating-ring-loader.gif" alt="">
                </div>
        </div>
    </div>
</div>
<?php echo $__env->make('inc.home.news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /* /home/karma/Desktop/My Project/SNEWS/resources/views/inc/home/content.blade.php */ ?>