<div class="ui right vertical sidebar menu icon-sidebar overlay">

    <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="item" dir="ltr">
        <div class="ui toggle checkbox">
        <input type="checkbox" name="public" @click="add_remove_source(<?php echo e($source->id); ?>)" :checked="selected_sources.indexOf(<?php echo e($source->id); ?>) > -1">
                <router-link tag="a" :to="'/' + lang + '/source/<?php echo e($source->slug); ?>' + (category ? '/category/' + category : '')"><?php echo e($source->source); ?></router-link>
        </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /* /home/additwlr/public_html/resources/views/inc/sidebar/right.blade.php */ ?>