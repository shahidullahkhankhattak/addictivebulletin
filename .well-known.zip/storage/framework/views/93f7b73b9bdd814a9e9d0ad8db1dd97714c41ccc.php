<head>
    <meta charset="UTF-8">
    <base href="/">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,400i,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Seaweed+Script" rel="stylesheet">
    <link rel="stylesheet" href="//fonts.googleapis.com/earlyaccess/notonastaliqurdudraft.css">
    <link rel="stylesheet" href="/css/semantic.min.css">
    <link rel="stylesheet" href="/css/app.css">
    <title>S NEWS | <?php echo e($page); ?> - <?php echo e($title); ?></title>
    <?php if ($story): ?>
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:site" content="@snews">

        <meta property="og:url" content="<?php echo e(Request::url()); ?>" />
        <meta property="og:type" content="article" />
        <meta property="og:title" content="<?php echo e($story->title); ?>" />
        <meta property="og:description" content="<?php echo e($story->description); ?>" />
        <meta property="og:image" content="<?php echo e($story->media); ?>" />
    <?php endif; ?>
    <script src="/js/jquery.min.js"></script>
    <script src="/js/semantic.min.js"></script>
    <script>
        window.story = <?php echo $story ? $story : 'null'; ?>;
        window.stories = <?php echo json_encode($news->items()); ?>;
        window.sources = <?php echo $sources; ?>;
        window.page = 1;
        function fadeIn(obj) {
            if (!window.isMobile) {
                if(obj)
                    $(obj).fadeIn(800);
            }
            else {
                if(obj)
                    $(obj).show();
            }
        }
    </script>
</head>

<?php /* /home/karma/Desktop/My Project/SNEWS/resources/views/inc/head.blade.php */ ?>