<script src="/js/app.js?v=9"></script>
<script async src="https://static.addtoany.com/menu/page.js"></script>
<?php /* /home/univer16/snews.shahidullahkhan.com/resources/views/inc/scripts.blade.php */ ?>